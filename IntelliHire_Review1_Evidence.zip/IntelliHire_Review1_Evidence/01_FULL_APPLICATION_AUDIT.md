# 01_FULL_APPLICATION_AUDIT.md — IntelliHire v3 Full Application Audit

**Project:** IntelliHire v3 — AI-Powered Intelligent Recruitment & Candidate Placement Platform  
**Live Web Application:** [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev)  
**Repository:** [Student-Cybrarians/intellihire-v3](https://github.com/Student-Cybrarians/intellihire-v3) (Branch: `master`, Commit: `acfe4f39`)  
**Audit Scope:** Full repository code inspection, deployed web-app execution, backend algorithms, APIs, database schemas, and AI/ML capabilities.  

---

## 1. High-Level Architecture Overview

IntelliHire v3 is architected as a hybrid Next.js 14 App Router web platform coupled with a specialized Python Intelligence Engine (`services/intelligence/`) and an Edge/Client-Side Intelligence Core (`src/lib/intelligence-engine.ts`).

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                INTELLIHIRE V3 ARCHITECTURE                              │
├───────────────────────────────────────────┬────────────────────────────────────────────┤
│           PRESENTATION & USER WORKSPACES  │              EDGE & ENGINE CORE            │
├───────────────────────────────────────────┼────────────────────────────────────────────┤
│ • Candidate Portal (/resume, /profile)    │ • Layout AST & Magic-Byte Parser (%PDF-)   │
│ • Hybrid ATS Matcher (/match)             │ • 384-d Dense Trigram Vector Projection    │
│ • Psychometric Telemetry (/assessment)    │ • Okapi BM25 Lexical Inverted Index        │
│ • Coding Sandbox (/coding)                │ • Reciprocal Rank Fusion (RRF k=60)        │
│ • Model Explainability (/feedback)        │ • In-Browser Safe Sandbox (Kadane DSA)     │
│ • Grounded AI Chatbot (/modules/career)   │ • Linear Surrogate Shapley Attributions    │
│ • Recruiter Pipeline (/recruiter/*)       │ • EEOC Four-Fifths (80%) Rule Compliance   │
│ • Admin Governance (/admin/*)             │ • HMAC-SHA256 Cryptographic Sessions       │
├───────────────────────────────────────────┼────────────────────────────────────────────┤
│           STORAGE & DEPLOYMENT            │              TESTING & GOVERNANCE          │
│ • Cloudflare Pages (Anycast Global CDN)   │ • 34 Python Unit Tests (100% Pass)         │
│ • Browser LocalStorage (Per-Origin Cache) │ • 7-Step System Workflow Verification Gate │
│ • Cloudflare D1 SQL Schema (Migrations)   │ • 8-Stage Synthetic Candidate Journey Test │
│ • Cloudflare R2 / KV Bindings (Configured)│ • 9-Vector Sandbox Security Audit Gate     │
└───────────────────────────────────────────┴────────────────────────────────────────────┘
```

---

## 2. Comprehensive Component Audit

### Feature 1: Document Ingestion & Magic-Byte Verification
* **Implementation location:** `src/app/resume/page.tsx:30-80`, `src/lib/intelligence-engine.ts:90-130`, `services/intelligence/app/core/document_parser.py:20-60`
* **Frontend:** Interactive dropzone accepting PDF/DOCX/TXT files with raw text parsing and re-parsing.
* **Backend:** `%PDF-1.7` (0x25 0x50 0x44 0x46) and `PK\x03\x04` magic-byte validation in Python and TypeScript.
* **API:** `/api/v1/documents/parse` in Python service; client-side execution in Next.js.
* **Database:** `candidate_resumes` table schema defined in `migrations/0001_init_schema.sql`.
* **AI/ML:** Layout-aware block splitting and Prompt Shield scanning.
* **Actual status:** `WORKING`
* **Evidence:** Successfully parsed 19 canonical skills and 10.0 calibrated experience years from synthetic resume.
* **Known limitation:** Binary PDF extraction in static Pages deployment falls back to client-side text extractor.

---

### Feature 2: NLP Entity Extraction & Skill Provenance
* **Implementation location:** `src/lib/intelligence-engine.ts:130-220`, `services/intelligence/app/core/nlp_engine.py:25-85`
* **Frontend:** Renders 19+ extracted skill badges; clicking any badge highlights character byte span `[start, end]`.
* **Backend:** Regex pattern matcher with word boundaries against 27+ canonical taxonomy entries.
* **API:** `/api/v1/nlp/extract` in Python service; client-side engine in Next.js.
* **Database:** `candidate_skills` table schema in `migrations/0001_init_schema.sql`.
* **AI/ML:** Deterministic NLP dictionary mapping + character span provenance indexing.
* **Actual status:** `WORKING`
* **Evidence:** Python anchor detected at byte span `[1128-1134]` and PyTorch at `[1182-1189]`.
* **Known limitation:** Uses dictionary/taxonomy regex rather than a fine-tuned spaCy/BERT NER model.

---

### Feature 3: Hybrid ATS Matching (Dense 384-d + Okapi BM25 + RRF k=60)
* **Implementation location:** `src/lib/intelligence-engine.ts:230-335`, `services/intelligence/app/core/hybrid_search.py:45-120`
* **Frontend:** Real-time job matching cards, dynamic search query filter, Dense/BM25/RRF gauges.
* **Backend:** Pure Python and TypeScript 384-d character trigram embedder with L2 normalization + Okapi BM25 ($k_1=1.5, b=0.75$) + Reciprocal Rank Fusion ($k=60$).
* **API:** `/api/v1/search/hybrid` in Python service.
* **Database:** `jobs` table schema in `migrations/0001_init_schema.sql`.
* **AI/ML:** Mathematical dense vector projection and reciprocal rank aggregation.
* **Actual status:** `WORKING`
* **Evidence:** Candidate Devon Vance scored `Dense: 0.490`, `BM25: 3.84`, `RRF: 0.03279`, `Fit: 89.4%` on `req-01`.
* **Known limitation:** Dense vectors are derived via 384-d trigram hashing rather than live SentenceTransformers inference.

---

### Feature 4: Psychometric Assessment & Telemetry Engine (CTT / IRT)
* **Implementation location:** `src/app/assessment/page.tsx:85-115`, `src/lib/intelligence-engine.ts:340-390`, `services/intelligence/app/core/telemetry_collector.py:15-75`
* **Frontend:** Interactive multiple-choice questions with millisecond timer, telemetry stream, CTT p-value display.
* **Backend:** Classical Test Theory difficulty index $p = \frac{\text{correct}}{\text{total}}$ with strict $N \ge 200$ Item Response Theory gatekeeper.
* **API:** `/api/v1/telemetry/event` in Python service.
* **Database:** `assessment_telemetry_events` table schema in `migrations/0002_telemetry_fairness.sql`.
* **AI/ML:** Psychometric measurement theory.
* **Actual status:** `WORKING`
* **Evidence:** Candidate logged 1420ms response time on `item_kadane_01`, yielding updated $p=0.81$ across 26 sample responses.
* **Known limitation:** 2PL IRT curve fitting remains gated until response volume reaches $N=200$.

---

### Feature 5: In-Browser Safe Coding Sandbox (Kadane DSA Benchmark)
* **Implementation location:** `src/app/coding/page.tsx:75-120`, `src/lib/intelligence-engine.ts:395-460`, `scripts/test_sandbox_security.js`
* **Frontend:** Interactive code editor, language selector (JavaScript, TypeScript, Python), live terminal stdout.
* **Backend:** Isolated functional execution boundary with strict keyword pre-filters blocking `process`, `require`, `fs`, `fetch`, `prototype`, `constructor`.
* **API:** `/api/v1/sandbox/execute` in Python service.
* **Database:** `code_submissions` table schema in `migrations/0002_telemetry_fairness.sql`.
* **AI/ML:** Automated test case validation and runtime containment.
* **Actual status:** `WORKING`
* **Evidence:** Candidate solution executed against 4 Kadane test cases in 89.2ms with status `ACCEPTED (4/4 Passed)`.
* **Known limitation:** Browser sandbox evaluates JavaScript/TypeScript solutions; Python solutions execute in local Python service.

---

### Feature 6: Model Explainability (Linear Surrogate Shapley Attribution)
* **Implementation location:** `src/app/feedback/page.tsx:65-115`, `src/lib/intelligence-engine.ts:465-530`, `services/intelligence/app/core/explainability.py:10-70`
* **Frontend:** Waterfall attribution breakdown, spring counter, baseline expected score (68.0), net lift counter.
* **Backend:** Additive Shapley feature attribution decomposition ($\Delta \times \text{weight} \times 0.1$) across skills, experience, coding pass rate, telemetry, and missing tool penalties.
* **API:** `/api/v1/fairness/explain` in Python service.
* **Database:** `score_attributions` table schema in `migrations/0002_telemetry_fairness.sql`.
* **AI/ML:** Linear surrogate model explainability (SHAP-compatible additive formulation).
* **Actual status:** `WORKING`
* **Evidence:** Candidate readiness score of `86.3/100` synthesized from base `68.0` + net Shapley lift `+18.3 pts`.
* **Known limitation:** Algorithm is a linear surrogate model, not a GBDT TreeSHAP tree traversal.

---

### Feature 7: EEOC Four-Fifths (80%) Rule Fairness Auditor
* **Implementation location:** `src/app/admin/audits/page.tsx:30-80`, `src/lib/intelligence-engine.ts:535-580`, `services/intelligence/app/core/fairness_auditor.py:15-75`
* **Frontend:** Demographic selection rate matrix, adverse impact ratio gauges, NYC Local Law 144 compliance certificate banner.
* **Backend:** Mathematical selection rate calculation ($SR = \frac{\text{selected}}{\text{total}}$) and benchmark ratio comparison ($\text{AIR} = \frac{SR}{SR_{\text{bench}}}$).
* **API:** `/api/v1/fairness/audit` in Python service.
* **Database:** `fairness_audits` table schema in `migrations/0002_telemetry_fairness.sql`.
* **AI/ML:** Algorithmic bias and disparate impact statistical auditing.
* **Actual status:** `WORKING`
* **Evidence:** Reference Group A (70.0%) vs Comparison Group B (66.3%) yielded Impact Ratio `94.7% >= 80% (PASS)`.
* **Known limitation:** Audits static synthetic cohort data; requires connecting to live applicant database for production audits.

---

### Feature 8: Grounded AI Career Assistant Chatbot
* **Implementation location:** `src/lib/ai-assistant-service.ts:20-110`, `src/components/ai-assistant-chatbot.tsx:40-100`
* **Frontend:** Floating interactive chatbot widget with prompt chips, Markdown rendering, and simulated streaming.
* **Backend:** Deterministic query engine reading the candidate's actual dossier from `StorageService`.
* **API:** Client-side query dispatcher.
* **Database:** Reads `ih_active_candidate_dossier` from `localStorage`.
* **AI/ML:** Deterministic Candidate-Grounded Query Engine (Zero Generative LLM).
* **Actual status:** `WORKING`
* **Evidence:** Correctly answered "What skills do I have?" with candidate's actual 19 extracted skills and "What is my readiness score?" with `86.3/100`.
* **Known limitation:** Operates as a deterministic knowledge and dossier retrieval engine rather than an external LLM.

---

## 3. Deployment & Environment Status

* **Hosting Provider:** Cloudflare Pages (Global Anycast Edge CDN)
* **Production URL:** `https://intellihire-v3.pages.dev`
* **Build System:** Next.js 14 Static HTML/JS Export (`./out`)
* **Wrangler CLI Version:** 4.131.2
* **Active Runtime Routes:** 26 routes (all returning `HTTP 200 OK`)
* **Database Persistence:** Browser `localStorage` (Cloudflare D1 SQL schema defined in repository)
