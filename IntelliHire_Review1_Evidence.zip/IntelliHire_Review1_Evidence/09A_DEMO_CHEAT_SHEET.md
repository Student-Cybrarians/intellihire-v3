# 09A_DEMO_CHEAT_SHEET.md — Quick One-Page Panel Cheat Sheet

**Live Demo URL:** [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev)  

---

### ⏱️ Quick 60-Second Demo Navigation Path

| Stage | URL Route | Key Action | What to Say / Point Out |
| :--- | :--- | :--- | :--- |
| **1. Ingest** | `/resume` | Click **"Re-parse Verified Resume"** | "%PDF-1.7 header validated, Prompt Shield active (0 injection threats), 19 skills extracted." |
| **2. Provenance**| `/profile` | Click **"PyTorch"** skill badge | "Character-span offset `[1182, 1189]` anchors directly to raw resume. Zero hallucination." |
| **3. Match** | `/match` | Click **"Principal AI Architect"** | "RRF $k=60$ fuses 384-d dense embeddings (0.892) + Okapi BM25 (3.84 pts) $\rightarrow$ 96.4% Fit." |
| **4. Coding** | `/coding` | Click **"Execute in Sandbox"** | "4/4 test cases passed in 89.2ms inside isolated functional sandbox." |
| **5. Score** | `/feedback` | Hover over waterfall chart | "Linear Shapley model: Base 68.0 + Lift 26.0 = 94.0/100. EEOC 80% Rule ratio = 0.94." |
| **6. Chatbot** | Floating Icon | Click **"What skills am I missing?"**| "100% grounded in candidate dossier; identifies Kubeflow/Triton gaps with zero hallucination." |

---

### 🧠 Core Formulas to Recite in Q&A

1. **Reciprocal Rank Fusion (RRF):**
   $$\text{RRF}(d) = \frac{1}{60 + \text{rank}_{\text{dense}}(d)} + \frac{1}{60 + \text{rank}_{\text{bm25}}(d)}$$
   *Say: "k=60 balances high-ranking dense vectors with exact lexical BM25 keywords."*

2. **EEOC Four-Fifths (80%) Rule:**
   $$\text{Adverse Impact Ratio} = \frac{\text{Selection Rate}_{\text{protected}}}{\text{Selection Rate}_{\text{benchmark}}} \ge 0.80$$
   *Say: "If any group's selection rate is below 80% of the highest group, it flags adverse impact."*

3. **Shapley Additive Explainability:**
   $$f(x) = \text{Base Value }(68.0) + \sum \phi_i(x)$$
   *Say: "Linear surrogate Shapley model transparently attributes score points to verified skills, experience, and coding pass rate."*

---

### ⚠️ What NOT to Claim:
- **DO NOT** claim the system runs a trained deep transformer model on the server; say: *"We use a 384-dimensional character-trigram dense vector projection with L2 normalization."*
- **DO NOT** claim the chatbot is ChatGPT or Claude API; say: *"It is a candidate-grounded deterministic knowledge engine."*
- **DO NOT** claim TreeSHAP is running a GBDT tree ensemble; say: *"It is a Linear Surrogate Shapley Additive Feature Attribution model."*
