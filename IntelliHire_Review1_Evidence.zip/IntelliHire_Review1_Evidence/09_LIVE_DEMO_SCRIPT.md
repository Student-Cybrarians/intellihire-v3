# 09_LIVE_DEMO_SCRIPT.md — Step-by-Step Live Review-1 Panel Presentation Script

**Project:** IntelliHire v3 — Intelligent AI Recruitment & Placement Platform  
**Live Web Application:** [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev)  
**Duration:** 5–7 Minutes Live Demonstration  

---

## 1. BEFORE DEMO (Preparation Checklist)

1. Open a clean browser window to [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev).
2. Have tabs open or ready:
   - Tab 1: [https://intellihire-v3.pages.dev/resume](https://intellihire-v3.pages.dev/resume) (Resume Ingest)
   - Tab 2: [https://intellihire-v3.pages.dev/profile](https://intellihire-v3.pages.dev/profile) (Structured Dossier & Provenance)
   - Tab 3: [https://intellihire-v3.pages.dev/match](https://intellihire-v3.pages.dev/match) (Hybrid ATS Matcher)
   - Tab 4: [https://intellihire-v3.pages.dev/coding](https://intellihire-v3.pages.dev/coding) (Coding Sandbox)
   - Tab 5: [https://intellihire-v3.pages.dev/feedback](https://intellihire-v3.pages.dev/feedback) (Shapley Scorecard)
   - Tab 6: [https://intellihire-v3.pages.dev/admin/audits](https://intellihire-v3.pages.dev/admin/audits) (EEOC Compliance Center)
3. Ensure laptop screen brightness is high and zoom is at 100% or 110%.

---

## 2. STEP-BY-STEP LIVE DEMO FLOW

### Step 1: Introduction & Architecture Overview (0:00 – 1:00)
* **WHAT I DO:** Open homepage (`/`). Point to the top status bar.
* **WHAT THE PANEL SEES:** The enterprise dark theme, "Cloudflare Edge Live", "D1 SQL + KV + R2", and "EEOC 80% Audited" status badges.
* **WHAT I SAY:**
  > "Respected panel members, today we present **IntelliHire v3**, an AI-driven recruitment and candidate intelligence platform. Unlike traditional ATS systems that rely on naive keyword matching or unexplainable black-box neural networks, IntelliHire v3 combines layout-aware document ingestion, 384-dimensional dense semantic vector search, Okapi BM25 keyword matching with Reciprocal Rank Fusion, safe code execution sandboxes, and linear Shapley feature attribution with EEOC 80% fairness compliance."
* **TECHNICAL EXPLANATION:** Point out the modular architecture and edge-deployed Next.js App Router topology.

---

### Step 2: Document Ingestion & Prompt Injection Defense (1:00 – 2:00)
* **WHAT I DO:** Navigate to `/resume`. Click "Re-parse Verified Resume".
* **WHAT THE PANEL SEES:** Pre-flight checks pass: `%PDF-1.7` magic bytes verified, Prompt Shield active (0 injection threats), 19 canonical skills extracted.
* **WHAT I SAY:**
  > "Here in Module 1, we ingest unstructured candidate resumes. First, our engine performs binary magic-byte verification to confirm file integrity. Next, our Prompt Shield scans the text for adversarial injections—such as ChatML delimiters or instruction overrides—before parsing. The layout AST engine extracts canonical skills and calibrates years of experience."
* **ACTUAL RESULT:** Extracted 19 skills, 10.0 calibrated experience years, and character-level offset boundaries.

---

### Step 3: Structured Profile & Zero-Hallucination Provenance (2:00 – 3:00)
* **WHAT I DO:** Navigate to `/profile`. Click on the skill badge for "PyTorch" and then "Qdrant".
* **WHAT THE PANEL SEES:** The right-hand inspector updates dynamically to show the exact character range `[1182, 1189]` and the source resume text excerpt.
* **WHAT I SAY:**
  > "To eliminate AI hallucination, IntelliHire establishes character-span provenance. Notice when I click on 'PyTorch' or 'Qdrant', the system displays the exact character offset in the candidate's resume where that qualification was verified. This guarantees 100% auditable grounded truth for recruiters."
* **ACTUAL RESULT:** 100% provenance coverage verified.

---

### Step 4: Hybrid ATS Matching & Reciprocal Rank Fusion (3:00 – 4:15)
* **WHAT I DO:** Navigate to `/match`. Point to the RRF formula card at the top. Click on different requisitions.
* **WHAT THE PANEL SEES:** The 3 gauges update: Dense Cosine Similarity (`0.892`), Okapi BM25 Score (`3.84`), and Fused RRF Rank (`0.01639`), giving a `96.4% Fit`.
* **WHAT I SAY:**
  > "This is our core algorithmic innovation—Hybrid ATS Matching using Reciprocal Rank Fusion (RRF with constant k=60). We project the candidate and job requisitions into a 384-dimensional semantic dense vector space and combine it with sparse Okapi BM25 keyword matching. This mathematically prevents candidates from gaming the system through keyword stuffing while preserving exact term requirements."
* **TECHNICAL EXPLANATION:** Explain formula $\text{RRF}(d) = \frac{1}{60 + r_{\text{dense}}} + \frac{1}{60 + r_{\text{bm25}}}$.

---

### Step 5: Isolated Coding Sandbox Execution (4:15 – 5:15)
* **WHAT I DO:** Navigate to `/coding`. Click "Execute in Sandbox".
* **WHAT THE PANEL SEES:** The terminal prints step-by-step stdout; all 4 test cases pass with status `ACCEPTED` in 89.2ms.
* **WHAT I SAY:**
  > "In Module 3, candidates complete algorithmic coding benchmarks. Rather than trusting candidate self-claims, code is executed inside a safe, isolated sandbox boundary with strict timeout and memory limits. All 4 validation test cases for Kadane's algorithm passed in under 90 milliseconds."
* **ACTUAL RESULT:** 4/4 Passed, Status ACCEPTED, 89.2ms latency, 18.4MB memory.

---

### Step 6: Model Explainability & EEOC 80% Rule Compliance (5:15 – 6:15)
* **WHAT I DO:** Navigate to `/feedback`. Hover over the waterfall attribution bars. Point to the EEOC badge.
* **WHAT THE PANEL SEES:** The waterfall chart decomposing the score from baseline 68.0 to 94.0 (+12.4 skills, +8.2 experience, +4.3 coding, +3.1 telemetry, -2.0 gaps).
* **WHAT I SAY:**
  > "Finally, we address AI governance. Instead of an unexplainable black-box score, our Linear Surrogate Shapley Feature Attribution decomposes the candidate's score into transparent positive and negative contributions. Furthermore, our EEOC Disparate Impact Auditor verifies that demographic selection rates pass the Four-Fifths (80%) Rule with a 0.94 parity ratio under NYC Local Law 144."
* **ACTUAL RESULT:** Base 68.0 + Net Lift 26.0 = 94.0/100, Disparate Impact Ratio = 0.94 (PASS).

---

### Step 7: Grounded AI Assistant Query (6:15 – 7:00)
* **WHAT I DO:** Click the floating AI icon in the bottom right corner. Click prompt chip "What skills am I missing?".
* **WHAT THE PANEL SEES:** The assistant immediately returns a structured Markdown breakdown of candidate missing skills (`Kubeflow`, `Triton`).
* **WHAT I SAY:**
  > "Candidates can interact with our Career Assistant, which is directly grounded in their verified dossier to provide factual feedback with zero hallucinations."
* **DEMO CONCLUSION:**
  > "In summary, IntelliHire v3 successfully implements data preprocessing, hybrid RRF matching, safe sandboxed execution, explainable scoring, and compliance auditing across a live, edge-deployed platform. Thank you, and we look forward to your questions."
