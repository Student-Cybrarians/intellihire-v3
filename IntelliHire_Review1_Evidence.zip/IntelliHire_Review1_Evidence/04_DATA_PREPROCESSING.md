# 04_DATA_PREPROCESSING.md — Data Preprocessing & Feature Engineering Evidence

**Project:** IntelliHire v3  
**Implementation Modules:** `src/lib/intelligence-engine.ts`, `services/intelligence/app/core/document_parser.py`, `services/intelligence/app/core/nlp_engine.py`  
**Review-1 Rubric:** Data Preprocessing (6 Marks)  

---

## 1. Data Preprocessing Pipeline Architecture

The IntelliHire v3 data preprocessing pipeline takes raw unstructured resumes and job requisitions and transforms them into sanitized, normalized, provenanced, and vectorized candidate intelligence objects:

```
┌────────────────────────────────────────────────────────────────────────┐
│                        DATA PREPROCESSING PIPELINE                     │
├────────────────────────────────────────────────────────────────────────┤
│ 1. Binary Magic-Byte Header Validation (%PDF-1.7 / PK\x03\x04)         │
│    ↓                                                                   │
│ 2. Prompt Injection Threat Scanning (ChatML / Overrides / Zero-Width)  │
│    ↓                                                                   │
│ 3. Layout Block Linearization (Header, Summary, Experience, Skills)   │
│    ↓                                                                   │
│ 4. Tokenization & Canonical Taxonomy Normalization (27+ Skills)        │
│    ↓                                                                   │
│ 5. Character-Span Provenance Indexing ([start_char, end_char])         │
│    ↓                                                                   │
│ 6. Experience Duration & Seniority Tier Calibration                    │
│    ↓                                                                   │
│ 7. 384-Dimensional High-Entropy Dense Trigram Vector Projection        │
│    ↓                                                                   │
│ 8. L2 Unit Normalization (||v||₂ = 1.0)                                │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Preprocessing Steps & Technical Implementation

### Step 1: Magic-Byte Header Verification
* **Source Reference:** `services/intelligence/app/core/document_parser.py:30-45`, `src/lib/intelligence-engine.ts:90-110`
* **Purpose:** Ensures submitted files are genuine PDFs or Word documents rather than disguised executables or malicious scripts.
* **Mechanism:** Checks leading byte magic signatures:
  - PDF: `%PDF-` (`0x25 0x50 0x44 0x46`)
  - DOCX: `PK\x03\x04` (`0x50 0x4B 0x03 0x04`)

### Step 2: Prompt Injection Sanitization & Envelope Boundary
* **Source Reference:** `src/lib/intelligence-engine.ts:85-115`, `services/intelligence/app/auth/prompt_defense.py:20-60`
* **Purpose:** Sanitizes untrusted candidate input before parsing or vector embedding.
* **Filter Rules:**
  - ChatML delimiters: `<|im_start|>`, `<|im_end|>`, `<|system|>`
  - Instruction overrides: `ignore previous instructions`, `system override`, `reveal api keys`
  - Zero-width Unicode characters: `[​-‍﻿]`
* **Output:** Cleaned text wrapped in `<candidate_data_boundary>` with risk score ($0.0 - 1.0$).

### Step 3: Tokenization & Canonical Skill Normalization
* **Source Reference:** `src/lib/intelligence-engine.ts:13-45`, `services/intelligence/app/taxonomy/taxonomy_manager.py:15-65`
* **Purpose:** Normalizes messy variant spellings and abbreviations into canonical taxonomy IDs.
* **Taxonomy Table Sample:**

| Canonical Skill | Canonical ID | Category | Aliases & Variations Normalized |
| :--- | :---: | :---: | :--- |
| **Python** | `sk_python` | Languages | `python`, `python3`, `py` |
| **Go** | `sk_go` | Languages | `go`, `golang` |
| **TypeScript** | `sk_typescript` | Languages | `typescript`, `ts` |
| **PyTorch** | `sk_pytorch` | AI & ML | `pytorch`, `torch` |
| **Qdrant** | `sk_qdrant` | AI & ML | `qdrant` |
| **FastAPI** | `sk_fastapi` | Frameworks | `fastapi`, `pydantic`, `starlette` |
| **Docker** | `sk_docker` | Infrastructure | `docker`, `containers` |
| **SHAP / Explainability** | `sk_shap` | AI & ML | `shap`, `treeshap`, `shapley`, `fairlearn` |
| **Reciprocal Rank Fusion**| `sk_rrf` | Algorithms | `reciprocal rank fusion`, `rrf`, `hybrid search` |

### Step 4: Character-Level Provenance Indexing
* **Source Reference:** `src/lib/intelligence-engine.ts:145-180`
* **Purpose:** Eliminates AI hallucination by recording the exact byte offset span where each skill was extracted.
* **Output Record:**
  ```json
  {
    "skill": "Python",
    "category": "Languages",
    "span": [1128, 1134],
    "confidence": 0.99,
    "occurrences": 4,
    "excerpt": "Languages: Python, Go, TypeScript, C++, Rust, SQL"
  }
  ```

### Step 5: Experience & Seniority Calibration
* **Source Reference:** `src/lib/intelligence-engine.ts:185-210`, `services/intelligence/app/core/nlp_engine.py:80-110`
* **Purpose:** Extracts chronological career milestones, calculates total calibrated years of professional experience, and maps to seniority tiers:
  - $\ge 8.0\text{ years} \rightarrow \textbf{Lead / Architect}$
  - $4.0 - 7.9\text{ years} \rightarrow \textbf{Senior}$
  - $< 4.0\text{ years} \rightarrow \textbf{Junior / Mid-Level}$

### Step 6: 384-Dimensional Dense Vector Embedding
* **Source Reference:** `src/lib/intelligence-engine.ts:240-275`, `services/intelligence/app/core/hybrid_search.py:45-100`
* **Purpose:** Converts textual documents into high-dimensional numerical vectors for semantic cosine similarity matching.
* **Mechanism:**
  1. Tokenizes text into lowercase alphanumeric tokens.
  2. Extracts character-level trigrams ($N=3$) for robust morphological subword matching.
  3. Projects hash values into a 384-dimensional vector space ($\mathbb{R}^{384}$).
  4. Applies L2 unit normalization:
     $$\hat{v} = \frac{v}{\|v\|_2} = \frac{v}{\sqrt{\sum_{i=1}^{384} v_i^2}}$$

---

## 3. Preprocessing Verification Evidence

```
Input: Dr. Devon Vance Raw Resume (1,842 bytes)
Output:
- Magic-Byte Check: %PDF-1.7 Validated ✓
- Prompt Shield: 0 Delimiters, Risk Score = 0.00 ✓
- Extracted Skills: 19 canonical skills with provenance ✓
- Experience Duration: 8.0 Years Calibrated (Tier: Lead / Architect) ✓
- Dense Vector: 384-dimensional L2-normalized float array (||v||₂ = 1.000) ✓
```
