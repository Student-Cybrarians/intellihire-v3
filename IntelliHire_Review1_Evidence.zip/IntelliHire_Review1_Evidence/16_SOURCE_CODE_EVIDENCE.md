# 16_SOURCE_CODE_EVIDENCE.md — Source Code Mapping & Technical Anchors

**Project:** IntelliHire v3  
**Repository:** [Student-Cybrarians/intellihire-v3](https://github.com/Student-Cybrarians/intellihire-v3) (Branch: `master`, Commit: `acfe4f39`)  

---

## Technical Claims vs. Exact Source Code Line Anchors

| Technical Claim / Feature | Source File | Exact Line Numbers | Implementation Mechanism |
| :--- | :--- | :---: | :--- |
| **Prompt Injection Defense** | `src/lib/intelligence-engine.ts` | Lines 85–115 | Regular expression and delimiter detection (`<|im_start|>`, `<|im_end|>`, overrides, zero-width characters). |
| **Canonical Skill Taxonomy** | `src/lib/intelligence-engine.ts` | Lines 13–45 | 27+ canonical technical skills with normalized alias dictionary. |
| **Layout AST Resume Parsing** | `src/lib/intelligence-engine.ts` | Lines 120–225 | Regex token extraction, character span indexing `[start, end]`, and chronological experience calculation. |
| **384-d Dense Embedding Vector**| `src/lib/intelligence-engine.ts` | Lines 240–275 | 384-dimensional character-trigram hashing projection with L2 unit normalization ($\|\hat{v}\|_2 = 1.0$). |
| **Cosine Similarity Distance** | `src/lib/intelligence-engine.ts` | Lines 275–285 | Vector dot product: $\sum u_i v_i$. |
| **Okapi BM25 Keyword Scoring** | `src/lib/intelligence-engine.ts` | Lines 285–310 | Inverted index frequency calculation ($k_1=1.5, b=0.75, \text{avgdl}=50$). |
| **Reciprocal Rank Fusion (RRF)** | `src/lib/intelligence-engine.ts` | Lines 325–340 | Mathematical rank aggregation: $\text{RRF}(d) = \frac{1}{60 + r_{\text{dense}}} + \frac{1}{60 + r_{\text{bm25}}}$. |
| **Sandbox Security Pre-Filters** | `src/lib/intelligence-engine.ts` | Lines 405–430 | Rejection of forbidden host and prototype identifiers (`process`, `require`, `fs`, `fetch`, `constructor`). |
| **Safe JavaScript Sandbox Execution**| `src/lib/intelligence-engine.ts` | Lines 435–480 | In-browser functional evaluation against 4 Kadane dynamic programming test cases. |
| **Linear Shapley Attribution Model**| `src/lib/intelligence-engine.ts` | Lines 485–540 | Decomposes readiness score from baseline $68.0\text{ pts}$ into additive constituent lifts. |
| **EEOC 80% Rule Disparate Impact** | `src/lib/intelligence-engine.ts` | Lines 545–585 | Selection rate ratio calculation against reference benchmark ($\text{AIR} = \frac{\text{SR}}{\text{SR}_{\text{bench}}} \ge 0.80$). |
| **Unified Storage Service** | `src/lib/storage-service.ts` | Lines 1–275 | Persistent candidate dossier and requisition management in browser `localStorage`. |
| **HMAC-SHA256 Session Crypto** | `src/lib/session.ts` | Lines 1–155 | Cryptographically secure HMAC-SHA256 session token generation and timing-safe verification. |
| **Grounded AI Career Assistant** | `src/lib/ai-assistant-service.ts` | Lines 1–180 | Deterministic query engine reading candidate skills, missing requirements, and readiness scorecard. |
| **Cloudflare D1 SQL Migrations** | `migrations/0001_init_schema.sql` | Lines 1–95 | SQL tables for tenants, users, candidate profiles, resumes, skills, and jobs. |
| **Assessment Telemetry Schema** | `migrations/0002_telemetry_fairness.sql`| Lines 1–81 | SQL tables for assessment events, code submissions, attributions, and fairness audits. |
