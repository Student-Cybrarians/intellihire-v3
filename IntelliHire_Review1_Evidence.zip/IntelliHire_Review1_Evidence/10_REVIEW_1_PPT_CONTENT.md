# 10_REVIEW_1_PPT_CONTENT.md — Review-1 Presentation Slide Deck Content

**Project Title:** IntelliHire v3 — Intelligent AI Recruitment, Hybrid ATS Ranking, and Model Governance Platform  
**Live Deployed URL:** [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev)  
**Slide Count:** 18 Slides (Strictly mapped to Review-1 Rubric)

---

### Slide 1 — Title Slide
* **Title:** IntelliHire v3: Intelligent Recruitment & Placement Platform
* **Subtitle:** Layout-Aware AST Ingestion, Hybrid Dense-Sparse ATS Retrieval (RRF k=60), Safe Code Execution Sandboxing, and Explainable AI Governance
* **Presented by:** [Student Team Names / Roll Numbers]
* **Under the Guidance of:** [Guide / Professor Name]
* **Department:** Department of Computer Science & Engineering
* **Deployment Link:** `https://intellihire-v3.pages.dev`

---

### Slide 2 — Problem Statement
* **The Challenges of Modern Recruitment:**
  1. **Keyword Stuffing & ATS Gaming:** Traditional ATS relies on naive keyword counters, rewarding deceptive resumes over genuine expertise.
  2. **Black-Box AI Decisions:** Deep neural scoring models lack transparency, making it impossible for candidates to know why they were rejected.
  3. **Algorithmic Discrimination:** AI screening models risk violating federal equal opportunity hiring laws (EEOC Uniform Guidelines & NYC Local Law 144).
  4. **Unvalidated Skill Claims:** Resumes are self-reported without empirical verification via coding benchmarks or telemetry.

---

### Slide 3 — Motivation
* **Why Build IntelliHire v3?**
  * Automated recruitment processes over 75% of resumes today; unfair or inaccurate filtering rejects qualified talent.
  * Emerging global regulations (NYC LL144, EU AI Act) mandate explainability and disparate impact bias auditing in employment decisions.
  * Need for an end-to-end platform bridging resume ingestion, hybrid retrieval, empirical skill verification, and auditable governance.

---

### Slide 4 — Project Objectives
* **Core Review-1 Objectives:**
  * Implement binary magic-byte verification (`%PDF-1.7`) and Prompt Injection Shielding.
  * Extract 27+ canonical technical skills with character-level text provenance.
  * Architect a Hybrid ATS Search engine combining 384-dimensional dense semantic vectors with Okapi BM25 keyword matching via Reciprocal Rank Fusion ($k=60$).
  * Build an isolated code execution sandbox for automated algorithmic benchmarking (Kadane DSA suite).
  * Synthesize an explainable candidate readiness score using Linear Surrogate Shapley Additive Feature Attribution.
  * Deploy automated EEOC Four-Fifths (80%) Rule disparate impact auditing.

---

### Slide 5 — Existing Systems vs. Proposed System

| Dimension | Existing Systems (Workday, Taleo, Greenhouse) | Proposed System (IntelliHire v3) |
| :--- | :--- | :--- |
| **Parsing** | Naive string matching; vulnerable to font hacks | Layout-aware AST parsing with Prompt Shield |
| **Matching** | Exact keyword counters or opaque embeddings | Hybrid 384-d Dense + BM25 with RRF $k=60$ |
| **Skill Verification**| Self-reported text | Isolated code execution sandbox |
| **Explainability** | Closed black box ("Rejected") | Transparent Shapley waterfall decomposition |
| **Compliance** | Manual external audit reports | Real-time EEOC 80% Rule disparate impact audit |
| **Edge Deployment**| Centralized monolithic servers | Globally distributed Cloudflare Anycast Edge |

---

### Slide 6 — Proposed System Architecture
* **Four-Tier Architecture:**
  1. **Client / Presentation Layer:** Next.js 14 App Router with Tailwind CSS, Lucide Icons, and Framer Motion.
  2. **Edge Processing Core:** TypeScript Intelligence Engine (`src/lib/intelligence-engine.ts`) with pure functional execution boundaries.
  3. **Intelligence & Telemetry Service:** Python 3.11 backend with Pydantic schemas, NLP extraction, and standalone HTTP server.
  4. **Storage & Persistence:** Unified browser `StorageService` cache with Cloudflare D1 SQLite relational schema migrations.

---

### Slide 7 — System Architecture Diagram
```
[Candidate Resume (PDF/DOCX/TXT)]
              │
              ▼
   ┌───────────────────────┐
   │ Binary Pre-Flight &   │
   │ Prompt Shield Defense │
   └──────────┬────────────┘
              │
              ▼
   ┌───────────────────────┐
   │  Layout AST & NLP     │ ──> Character-Span Provenance [start, end]
   │  Taxonomy Extraction  │
   └──────────┬────────────┘
              │
              ▼
   ┌───────────────────────┐
   │ Hybrid ATS Matcher    │ ──> 384-d Dense Cosine + Okapi BM25 + RRF (k=60)
   └──────────┬────────────┘
              │
              ▼
   ┌───────────────────────┐
   │ Isolated Code Sandbox │ ──> Subprocess / Functional AST Test Suite (4/4 Pass)
   └──────────┬────────────┘
              │
              ▼
   ┌───────────────────────┐
   │ Shapley Scorecard &   │ ──> Baseline 68.0 + Constituent Lifts = Readiness
   │ EEOC 80% Rule Audit   │ ──> Adverse Impact Ratio >= 0.80 PASS
   └───────────────────────┘
```

---

### Slide 8 — Methodology
* **Six-Stage Engineering Methodology:**
  * **Stage 1 (Ingestion):** Binary header validation and prompt defense sanitizer.
  * **Stage 2 (NLP):** Regex token extraction against 27+ canonical taxonomy entries.
  * **Stage 3 (Hybrid Search):** Dense vector projection + BM25 keyword index + RRF $k=60$.
  * **Stage 4 (Assessment):** Millisecond latency logging + CTT difficulty index ($p$).
  * **Stage 5 (Sandbox):** Safe sandbox test execution with resource boundaries.
  * **Stage 6 (Governance):** Additive Shapley feature decomposition + EEOC 80% rule validation.

---

### Slide 9 — Data Preprocessing
* **Techniques Implemented:**
  * **Input Normalization:** Lowercasing, punctuation stripping, subword trigram generation ($N=3$).
  * **Taxonomy Dictionary:** 27+ canonical technical skills mapped to IDs (`sk_python`, `sk_pytorch`, `sk_qdrant`).
  * **Experience Extraction:** Chronological year extraction ($\text{Latest} - \text{Earliest}$) mapping to Seniority Tiers.
  * **Vector Normalization:** L2 unit norm applied to 384-dimensional dense projections ($\|\hat{v}\|_2 = 1.0$).

---

### Slide 10 — Model & Algorithm Design
* **Key Mathematical Formulations:**
  1. **Reciprocal Rank Fusion:**
     $$\text{RRF}(d) = \frac{1}{60 + \text{rank}_{\text{dense}}(d)} + \frac{1}{60 + \text{rank}_{\text{bm25}}(d)}$$
  2. **Okapi BM25 Lexical Score:** Term frequency saturation ($k_1=1.5, b=0.75$).
  3. **Classical Test Theory:** Difficulty index $p = \frac{\text{correct}}{\text{total}}$ with $N \ge 200$ IRT sample gate.
  4. **Shapley Additive Attribution:** $f(x) = \phi_0 (68.0) + \sum \phi_i(x)$.
  5. **EEOC Adverse Impact Ratio:** $\text{AIR} = \frac{\text{SR}_{\text{protected}}}{\text{SR}_{\text{benchmark}}} \ge 0.80$.

---

### Slide 11 — Technologies & Tooling
* **Frontend:** Next.js 14 App Router, React 18, TypeScript 5.5, Tailwind CSS, Framer Motion, Lucide Icons.
* **Backend:** Python 3.11, Standalone Zero-Dependency HTTP Server, Pydantic, Subprocess Runner.
* **Security:** Web Crypto HMAC-SHA256 session signatures with timing-safe comparison.
* **Edge & Cloud:** Cloudflare Pages (Global Anycast CDN), Cloudflare D1 SQLite Schema, Wrangler CLI 4.131.2.
* **Testing:** PyUnit / Unittest, Node.js Assertions, Headless Chrome Automation.

---

### Slide 12 — Implementation Status
* **Completed & Demonstrable Modules:**
  * Module 1: Document Ingestion & Prompt Defense (`/resume`) — `WORKING`
  * Module 2: Structured Profile & Character Provenance (`/profile`) — `WORKING`
  * Module 3: Hybrid ATS Matcher with RRF $k=60$ (`/match`) — `WORKING`
  * Module 4: Psychometric Telemetry & CTT Index (`/assessment`) — `WORKING`
  * Module 5: Isolated Coding Sandbox with Kadane DSA (`/coding`) — `WORKING`
  * Module 6: Model Explainability & Shapley Scorecard (`/feedback`) — `WORKING`
  * Module 7: EEOC Four-Fifths Fairness Auditor (`/admin/audits`) — `WORKING`
  * Module 8: Grounded AI Career Assistant (`/modules/career`) — `WORKING`

---

### Slide 13 — Testing & Quality Assurance
* **Automated Test Results (100% Pass):**
  * TypeScript Static Compilation (`tsc --noEmit`): 0 Errors across 26 routes.
  * Sandbox Adversarial Security Suite: 9/9 Attack Vectors Neutralized.
  * Synthetic Candidate Journey Suite: 8/8 Stages Passed.
  * Python Intelligence Test Suite: 34/34 Tests Passed in 0.78s.
  * Full System Workflow Gate: 7/7 Verification Steps Certified.

---

### Slide 14 — Initial Results & Live Proof
* **Demonstrated Findings on Synthetic Candidate (Dr. Devon Vance):**
  * Extracted Skills: 19 Verified Skills (Python, Go, PyTorch, Qdrant, Docker, RRF).
  * Hybrid Fit Score: `89.4%` on Principal AI Architect requisition (`req-01`).
  * Sandbox Benchmark: `4/4 Passed` (100% Acceptance, 89.2ms execution latency).
  * Final Readiness Score: `86.3 / 100` (Base 68.0 + Net Lift +18.3).
  * EEOC Disparate Impact Ratio: `0.947` ($\ge 0.800$ Compliant PASS).

---

### Slide 15 — Applications & Industry Value
* **Target Industry Use Cases:**
  * **Enterprise HR Tech:** Scalable, unbiased screening for tech companies processing 100K+ applications/year.
  * **Candidate Upskilling:** Actionable feedback pointing candidates to specific skill gaps (e.g. Kubeflow, Triton).
  * **Regulatory Compliance:** Automated NYC Local Law 144 and EEOC disparate impact audit certification export.
  * **Technical Recruiting Agencies:** Zero-hallucination character-span dossiers for verified candidate submission.

---

### Slide 16 — Limitations & Ground Truth
* **Documented System Boundaries:**
  * Current dense embeddings use deterministic character-trigram projections rather than server-hosted PyTorch neural transformers.
  * Model explainability utilizes a linear surrogate Shapley additive model rather than GBDT tree traversal.
  * Career assistant operates as a deterministic candidate-grounded knowledge engine rather than a generative cloud LLM.
  * Candidate persistence in the live Pages build is managed via browser `localStorage` and client memory.

---

### Slide 17 — Future Scope (Review-2 & Final Phase)
* **Planned Enhancements:**
  * **Cloudflare D1 Edge Workers:** Connect Next.js API routes to live distributed SQLite for centralized database storage.
  * **SentenceTransformers / ONNX Model Embedding:** Host lightweight quantized transformer models on edge workers.
  * **Live Multi-Language Sandboxing:** Deploy WebAssembly (Wasm) isolated worker pools for safe client-side C++/Python execution.
  * **Full Cloudflare Workers AI Integration:** Connect grounded chatbot to Meta Llama 3 / Mistral on Workers AI.

---

### Slide 18 — Conclusion
* **Summary of Achievements:**
  * Built, tested, and deployed an end-to-end intelligent recruitment web platform on Cloudflare Pages.
  * Replaced naive keyword counting with mathematically sound **Hybrid Dense-Sparse RRF ($k=60$)**.
  * Replaced black-box scoring with **Linear Shapley Additive Feature Attributions**.
  * Embedded automated **EEOC 80% Rule Disparate Impact Auditing**.
* **Live System Link:** `https://intellihire-v3.pages.dev`
* **Thank you! We welcome questions from the panel.**
