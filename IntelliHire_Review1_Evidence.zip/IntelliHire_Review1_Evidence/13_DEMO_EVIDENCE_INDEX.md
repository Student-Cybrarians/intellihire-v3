# 13_DEMO_EVIDENCE_INDEX.md — Panel Demo Evidence Index

**Project:** IntelliHire v3  
**Live Web App:** [https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev)  
**Total Captured Screenshots:** 15 Evidence Files  

---

## Evidence Index Catalog

### EVIDENCE-001
* **Screen:** Landing & Architecture Portal (`/`)
* **Purpose:** Demonstrates global Cloudflare edge status, enterprise dark theme, and navigation bar.
* **Actual Result:** HTTP 200 OK; badges display "Cloudflare Edge Live (275+ PoPs)", "D1 + KV + R2", "TreeSHAP Active".
* **Related Rubric:** Implementation & Architecture
* **File:** `screenshots/EVIDENCE_001_LANDING_PAGE.png`

---

### EVIDENCE-002
* **Screen:** Candidate Placement Dashboard (`/dashboard`)
* **Purpose:** Shows candidate overview, readiness score status, active requisitions, and module links.
* **Actual Result:** HTTP 200 OK; dynamic placement status cards and quick navigation to all modules.
* **Related Rubric:** Implementation Progress
* **File:** `screenshots/EVIDENCE_002_DASHBOARD.png`

---

### EVIDENCE-003
* **Screen:** Document Ingestion & AST Parser (`/resume`)
* **Purpose:** Proves binary magic-byte verification (`%PDF-1.7`), Prompt Shield defense, and skill extraction.
* **Actual Result:** HTTP 200 OK; extracts 19 canonical skills, validates 10.0 experience years, 0 injection threats.
* **Related Rubric:** Data Preprocessing (6 Marks)
* **File:** `screenshots/EVIDENCE_003_RESUME_PARSER.png`

---

### EVIDENCE-004
* **Screen:** Structured Candidate Dossier & Provenance Inspector (`/profile`)
* **Purpose:** Demonstrates character-span provenance anchoring to eliminate AI hallucination.
* **Actual Result:** HTTP 200 OK; clicking skill badge displays exact byte range `[1182, 1189]` and resume excerpt.
* **Related Rubric:** Data Preprocessing & Result Analysis
* **File:** `screenshots/EVIDENCE_004_STRUCTURED_PROFILE.png`

---

### EVIDENCE-005
* **Screen:** Hybrid ATS Matcher & RRF k=60 Scoring (`/match`)
* **Purpose:** Demonstrates 384-d dense semantic embeddings + Okapi BM25 keyword matching fused via RRF ($k=60$).
* **Actual Result:** HTTP 200 OK; displays Dense Score (0.892), BM25 Score (3.84 pts), RRF Score (0.01639), and 96.4% Fit.
* **Related Rubric:** Model Design & Implementation (6 Marks)
* **File:** `screenshots/EVIDENCE_005_HYBRID_ATS_MATCH.png`

---

### EVIDENCE-006
* **Screen:** Psychometric Assessment & Item Telemetry (`/assessment`)
* **Purpose:** Proves response latency tracking, CTT item difficulty index ($p=0.81$), and strict $N \ge 200$ IRT gate.
* **Actual Result:** HTTP 200 OK; records response latency `1420ms`, updates CTT p-value, and logs telemetry event.
* **Related Rubric:** Implementation & Result Analysis
* **File:** `screenshots/EVIDENCE_006_PSYCHOMETRIC_ASSESSMENT.png`

---

### EVIDENCE-007
* **Screen:** Isolated Code Execution Sandbox (`/coding`)
* **Purpose:** Demonstrates safe algorithmic benchmarking with Kadane's algorithm DSA test suite.
* **Actual Result:** HTTP 200 OK; 4/4 test cases pass with status `ACCEPTED` in 89.2ms inside isolated boundary.
* **Related Rubric:** Implementation & Testing (6 Marks)
* **File:** `screenshots/EVIDENCE_007_CODING_SANDBOX.png`

---

### EVIDENCE-008
* **Screen:** Model Explainability & Shapley Scorecard (`/feedback`)
* **Purpose:** Proves additive Shapley feature decomposition (Base 68.0 + Net Lift 26.0 = 94.0/100) and EEOC 80% Rule badge.
* **Actual Result:** HTTP 200 OK; animated waterfall chart displays exact constituent factor contributions.
* **Related Rubric:** Model Design & Result Analysis (6 Marks)
* **File:** `screenshots/EVIDENCE_008_SHAPLEY_SCORECARD.png`

---

### EVIDENCE-009
* **Screen:** Grounded AI Career Assistant (`/modules/career`)
* **Purpose:** Proves zero-hallucination factual guidance directly grounded in active candidate record.
* **Actual Result:** HTTP 200 OK; chatbot returns candidate's exact extracted skills and missing job requirements.
* **Related Rubric:** Implementation & Q&A
* **File:** `screenshots/EVIDENCE_009_CAREER_ASSISTANT.png`

---

### EVIDENCE-010
* **Screen:** Recruiter Enterprise Workspace (`/recruiter/dashboard`)
* **Purpose:** Shows recruiter pipeline overview, active requisitions, average hybrid search time (1.2ms), and EEOC parity.
* **Actual Result:** HTTP 200 OK; 3 active requisitions, candidate pipeline counts, and EEOC audited badges.
* **Related Rubric:** Implementation Progress
* **File:** `screenshots/EVIDENCE_010_RECRUITER_WORKSPACE.png`

---

### EVIDENCE-011
* **Screen:** Recruiter Candidate Pipeline & RRF Ranking (`/recruiter/candidates`)
* **Purpose:** Demonstrates candidate pipeline sorting by RRF fusion rank and verified skills count.
* **Actual Result:** HTTP 200 OK; candidates listed in order of RRF rank score with verified skills badges.
* **Related Rubric:** Result Analysis & Implementation
* **File:** `screenshots/EVIDENCE_011_CANDIDATE_PIPELINE.png`

---

### EVIDENCE-012
* **Screen:** Recruiter Candidate Dossier (`/recruiter/candidates/cand_vishnu_p01`)
* **Purpose:** Demonstrates full recruiter dossier inspection with 4-engine breakdown and offer CTA.
* **Actual Result:** HTTP 200 OK; displays RRF score, verified skills, sandbox pass rate, and Shapley readiness.
* **Related Rubric:** Implementation & Result Analysis
* **File:** `screenshots/EVIDENCE_012_CANDIDATE_DOSSIER.png`

---

### EVIDENCE-013
* **Screen:** EEOC Disparate Impact & NYC LL144 Auditor (`/admin/audits`)
* **Purpose:** Proves automated Four-Fifths (80%) Rule statistical auditing across protected demographic cohorts.
* **Actual Result:** HTTP 200 OK; selection rate matrix shows all cohorts exceeding 80% threshold (Impact Ratio = 0.947 PASS).
* **Related Rubric:** Model Design & Result Analysis
* **File:** `screenshots/EVIDENCE_013_EEOC_AUDITOR.png`

---

### EVIDENCE-014
* **Screen:** Prompt Shield & Adversarial Threat Simulator (`/admin/security`)
* **Purpose:** Demonstrates live adversarial testing against ChatML delimiters and instruction overrides.
* **Actual Result:** HTTP 200 OK; detects ChatML token, flags status as `CRITICAL (Threat Neutralized)`, isolates envelope.
* **Related Rubric:** Testing & Security (6 Marks)
* **File:** `screenshots/EVIDENCE_014_SECURITY_SHIELD.png`

---

### EVIDENCE-015
* **Screen:** Authentication & Persona Switcher (`/login`)
* **Purpose:** Shows multi-role authentication portal for Candidate, Recruiter, and Admin auditors.
* **Actual Result:** HTTP 200 OK; 1-click persona switching and secure HMAC-SHA256 session management.
* **Related Rubric:** Implementation & Security
* **File:** `screenshots/EVIDENCE_015_LOGIN_PAGE.png`
