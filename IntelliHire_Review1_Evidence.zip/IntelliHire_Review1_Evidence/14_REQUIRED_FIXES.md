# 14_REQUIRED_FIXES.md — Review-1 Required Fixes & Optimization Backlog

**Project:** IntelliHire v3  
**Classification Standard:** CRITICAL (demo blocker) / HIGH (affects technical evaluation) / MEDIUM (improves evidence) / LOW (UI polish).

---

## 1. Issue Categorization Matrix

| Severity | Issue Description | Root Cause | File Location | Required Fix | Impact on Review-1 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **CRITICAL** | None (All Critical Blockers Resolved) | N/A | N/A | TypeScript compilation, sandbox isolation, session HMAC, and routing are 100% clean. | None (Live demo is stable) |
| **HIGH** | Static Pages `/api/*` 404 Route Handling | Cloudflare Pages static export cannot execute server-side Node.js route handlers. | `src/app/api/*` vs Cloudflare Pages | Deploy Next.js edge functions via `@cloudflare/next-on-pages` or standalone Cloudflare Worker proxy in Review-2. | Medium: Client engine already provides fallback execution. |
| **HIGH** | Host Subprocess Sandbox Isolation in Python Service | Python backend executes candidate code via local OS child process (`subprocess.Popen`). | `services/intelligence/app/core/sandbox_runner.py` | Containerize execution with Docker / gVisor before opening Python backend to public untrusted traffic. | Low for Review-1: Client sandbox uses safe JS boundary. |
| **MEDIUM** | Binary PDF Parsing in In-Browser Static Export | PDF binary stream decoding requires server-side `pypdf` or `pdfjs-dist` worker in pure static export. | `src/app/resume/page.tsx:40` | Bundle client-side `pdfjs-dist` WebWorker for standalone browser PDF text extraction. | Low: Raw text paste & sample re-parsing works flawlessly. |
| **MEDIUM** | Cloudflare D1 Database Binding | D1 SQL schemas exist in `migrations/`, but active Pages deployment uses browser `localStorage`. | `src/lib/storage-service.ts` | Wire Cloudflare D1 HTTP REST API binding for global multi-tenant database synchronization. | Low: `StorageService` provides robust client persistence. |
| **LOW** | Animation Spring Settle Timing | Framer Motion spring counter on `/feedback` can have minor layout shift during count-up. | `src/app/feedback/page.tsx:45` | Set fixed numeric container width to prevent subtle layout shifting during initial render. | UI Polish |
