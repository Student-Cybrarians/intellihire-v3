# 05_MODEL_AND_ALGORITHM_DESIGN.md — Model & Algorithm Design Document

**Project:** IntelliHire v3  
**Implementation Modules:** `src/lib/intelligence-engine.ts`, `services/intelligence/app/core/hybrid_search.py`, `services/intelligence/app/core/explainability.py`, `services/intelligence/app/core/fairness_auditor.py`  
**Review-1 Rubric:** Model Design (6 Marks)  

---

## 1. Problem Statement & Mathematical Formulation

Traditional Applicant Tracking Systems (ATS) suffer from two major flaws:
1. **Keyword Stuffing Exploitation:** Simple lexical matching rewards candidates who repeat keywords without genuine technical depth.
2. **Black-Box Algorithmic Bias:** Unexplainable deep neural models risk violating federal equal employment opportunity regulations (e.g. EEOC 80% Rule and NYC Local Law 144).

IntelliHire v3 solves this via a **Deterministic Hybrid Dual-Encoder & Governance Architecture**:

```
                                   SYSTEM ALGORITHM FLOW
                                   
      Candidate Document                              Job Requisition
             │                                               │
             ▼                                               ▼
   ┌────────────────────┐                          ┌────────────────────┐
   │ 384-d Dense Vector │                          │ 384-d Dense Vector │
   └─────────┬──────────┘                          └─────────┬──────────┘
             │                                               │
             └───────────────────────┬───────────────────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │  Cosine Similarity  │
                          │   Dense Rank (r_D)  │
                          └──────────┬──────────┘
                                     │
                 ┌───────────────────┴───────────────────┐
                 │                                       │
                 ▼                                       ▼
     ┌───────────────────────┐               ┌───────────────────────┐
     │  Okapi BM25 Lexical   │               │ Reciprocal Rank Fusion│
     │   Sparse Rank (r_B)   │               │      RRF (k=60)       │
     └───────────┬───────────┘               └───────────┬───────────┘
                 │                                       │
                 └───────────────────┬───────────────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │  Hybrid Fit Score   │
                          └──────────┬──────────┘
                                     │
      ┌──────────────────────────────┼──────────────────────────────┐
      │                              │                              │
      ▼                              ▼                              ▼
┌──────────────┐             ┌──────────────┐             ┌───────────────────┐
│ CTT & IRT    │             │ Safe Sandbox │             │  Linear Shapley   │
│ Telemetry    │             │ DSA Code Run │             │ Feature Lift Model│
└──────┬───────┘             └──────┬───────┘             └─────────┬─────────┘
       │                            │                               │
       └────────────────────────────┼───────────────────────────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │ Final Readiness     │
                         │  Score (0-100)      │
                         └──────────┬──────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │ EEOC 80% Rule Audit │
                         │ (AIR >= 0.80 Pass)  │
                         └─────────────────────┘
```

---

## 2. Core Mathematical Algorithms

### Algorithm 1: Reciprocal Rank Fusion (RRF k=60)
Reciprocal Rank Fusion aggregates disparate scoring distributions (dense cosine $[-1, 1]$ vs. sparse BM25 $[0, \infty)$) into an unbiased unified ranking:

$$\text{RRF\_Score}(d) = \sum_{m \in M} \frac{1}{k + r_m(d)} = \frac{1}{60 + \text{rank}_{\text{dense}}(d)} + \frac{1}{60 + \text{rank}_{\text{bm25}}(d)}$$

Where:
* $k = 60$ is the standard smoothing constant preventing top-ranked outliers from dominating the aggregate score.
* $r_{\text{dense}}(d)$ is the 1-based rank position of document $d$ in the dense semantic retrieval list.
* $r_{\text{bm25}}(d)$ is the 1-based rank position of document $d$ in the Okapi BM25 keyword query list.

---

### Algorithm 2: Okapi BM25 Sparse Lexical Scoring
Given query $Q$ with terms $q_1, q_2, \dots, q_n$ and document $D$:

$$\text{BM25}(D, Q) = \sum_{i=1}^{n} \text{IDF}(q_i) \cdot \frac{f(q_i, D) \cdot (k_1 + 1)}{f(q_i, D) + k_1 \cdot \left(1 - b + b \cdot \frac{|D|}{\text{avgdl}}\right)}$$

Where parameters are calibrated to:
* $k_1 = 1.5$ (term frequency saturation factor)
* $b = 0.75$ (document length normalization factor)
* $\text{avgdl} = 50.0$ (corpus average document length)

---

### Algorithm 3: Classical Test Theory (CTT) Item Telemetry
For each assessment question $j$ across candidate response pool $N$:

$$p_j = \frac{\sum_{i=1}^{N} X_{ij}}{N}$$

Where:
* $X_{ij} \in \{0, 1\}$ is candidate $i$'s correctness score on item $j$.
* $p_j$ is the item difficulty index ($0.0 \le p_j \le 1.0$).
* $N \ge 200$ is the strict threshold gate required before parameterizing 2-Parameter Logistic (2PL) Item Response Theory:
  $$P(\theta) = \frac{1}{1 + e^{-a(\theta - b)}}$$

---

### Algorithm 4: Linear Surrogate Shapley Feature Attribution Model
To provide zero black-box transparency, the candidate readiness score is decomposed from a baseline population expected score $\phi_0 = 68.0\text{ pts}$:

$$f(x) = \phi_0 + \sum_{j=1}^{M} \phi_j(x)$$

Where constituent Shapley feature contributions $\phi_j$ are defined by:
1. **Verified Canonical Skills Lift:** $\phi_{\text{skills}} = (\text{Skills} - 10) \times 0.8$
2. **Seniority & Experience Lift:** $\phi_{\text{exp}} = (\text{Years} - 3.0) \times 1.15$
3. **Coding Sandbox Benchmark Lift:** $\phi_{\text{code}} = (\text{Pass\%} - 70) \times 0.14$
4. **Psychometric Telemetry Lift:** $\phi_{\text{telemetry}} = (p - 0.50) \times 10.0$
5. **Missing Skills Gap Penalty:** $\phi_{\text{gap}} = -1.0 \times \text{MissingCount}$

---

### Algorithm 5: EEOC Four-Fifths (80%) Rule Compliance Audit
Under the U.S. Equal Employment Opportunity Commission (EEOC) Uniform Guidelines on Employee Selection Procedures:

$$\text{Selection Rate (SR)}_g = \frac{\text{Selected Applicants}_g}{\text{Total Applicants}_g}$$

$$\text{Adverse Impact Ratio (AIR)}_g = \frac{\text{SR}_g}{\max_{h} (\text{SR}_h)}$$

$$\text{Compliance Condition} = \begin{cases} \text{COMPLIANT (PASS)}, & \text{if } \text{AIR}_g \ge 0.80 \\ \text{ADVERSE IMPACT DETECTED}, & \text{if } \text{AIR}_g < 0.80 \end{cases}$$

---

## 3. Honest Classification of AI/ML Capabilities

| Algorithmic Subsystem | Classification | Description & Reality |
| :--- | :---: | :--- |
| **NLP Entity Extraction** | `DETERMINISTIC ALGORITHM` | Regex dictionary mapping against 27+ canonical taxonomy entries. |
| **Dense Embeddings** | `DETERMINISTIC ALGORITHM` | 384-dimensional character-trigram hashing projection with L2 norm. |
| **ATS Retrieval & Ranking** | `DETERMINISTIC ALGORITHM` | Okapi BM25 + Dense Cosine Similarity + Reciprocal Rank Fusion ($k=60$). |
| **Score Explainability** | `LINEAR SURROGATE MODEL` | Additive Shapley feature decomposition (not a GBDT TreeSHAP traversal). |
| **Fairness Auditing** | `DETERMINISTIC STATISTICAL AUDIT`| Mathematical Four-Fifths Selection Ratio calculation. |
| **Career Assistant Chatbot**| `DETERMINISTIC QUERY ENGINE` | Candidate-grounded knowledge retrieval (Zero Generative LLM). |
