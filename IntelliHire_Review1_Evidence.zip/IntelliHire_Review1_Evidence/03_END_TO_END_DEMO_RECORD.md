# 03_END_TO_END_DEMO_RECORD.md — End-to-End Demo Execution Record

**Demo Subject:** Synthetic Candidate "Dr. Devon Vance" (*Principal Systems & Machine Learning Engineer*)  
**Execution Environment:** Deployed Live Web App ([https://intellihire-v3.pages.dev](https://intellihire-v3.pages.dev))  
**Target Requisition:** `req-01` (*Principal AI & Distributed Systems Architect*)  

---

## Complete End-to-End Execution Sequence

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                               USER ACTION SEQUENCE                              │
├─────────────────────────────────────────────────────────────────────────────────┤
│ [1] Land on Portal (/)                                                          │
│     ↓                                                                           │
│ [2] Enter Resume text on /resume & trigger "Re-parse Verified Resume"           │
│     ↓                                                                           │
│ [3] Verify Extracted Skills & Character Provenance on /profile                  │
│     ↓                                                                           │
│ [4] Execute Hybrid ATS Matching & Requisition Ranking on /match                 │
│     ↓                                                                           │
│ [5] Submit Psychometric Question & Log Item Telemetry on /assessment            │
│     ↓                                                                           │
│ [6] Code Kadane Solution & Execute Isolated Sandbox Tests on /coding            │
│     ↓                                                                           │
│ [7] Inspect Shapley Additive Scorecard & EEOC Audit on /feedback                │
│     ↓                                                                           │
│ [8] Recruiter Dossier Inspection on /recruiter/candidates/cand_vishnu_p01       │
│     ↓                                                                           │
│ [9] Query Grounded AI Assistant: "What skills am I missing?"                    │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

### Step 1: Portal Entry
* **USER ACTION:** User navigates to `https://intellihire-v3.pages.dev`
* **APPLICATION PROCESSING:** Client initializes Next.js router, verifies theme, renders header badges and navigation bar.
* **BACKEND/API:** Cloudflare Pages Anycast CDN serves pre-rendered HTML/JS bundle.
* **AI/ML/NLP:** None.
* **DATABASE:** `StorageService` reads initial seed or active dossier from `localStorage`.
* **OUTPUT:** Landing page with "Enterprise AI Placement" branding, live edge badges, and quick CTA buttons.

---

### Step 2: Resume Ingestion & Prompt Defense
* **USER ACTION:** User pastes Dr. Devon Vance's resume on `/resume` and clicks "Re-parse Verified Resume".
* **APPLICATION PROCESSING:**
  1. Validates magic bytes header `%PDF-1.7` (0x25 0x50 0x44 0x46).
  2. Runs `scanPromptInjection()` checking for ChatML delimiters (`<|im_start|>`), instruction overrides, and zero-width characters.
  3. Parses layout text into structured sections (Header, Summary, Experience, Skills, Education).
* **BACKEND/API:** `parseResumeText()` in `src/lib/intelligence-engine.ts`.
* **AI/ML/NLP:** Regex tokenization, canonical taxonomy mapping against 27+ skills, experience year extraction.
* **DATABASE:** Updates `ih_active_candidate_dossier` in browser `localStorage`.
* **OUTPUT:** Extracted 19 canonical skills (Python, Go, TypeScript, PyTorch, Qdrant, TreeSHAP, Docker, etc.), 8.0 calibrated experience years, Lead/Architect tier.

---

### Step 3: Structured Profile & Provenance Inspection
* **USER ACTION:** User navigates to `/profile` and clicks on skill badge "PyTorch".
* **APPLICATION PROCESSING:** Retrieves active candidate dossier and filters skill metadata.
* **BACKEND/API:** `StorageService.getActiveCandidate()`.
* **AI/ML/NLP:** Character-span indexing `[1182, 1189]` locating exact token in source resume text.
* **DATABASE:** Reads from `localStorage`.
* **OUTPUT:** Right-hand card displays:
  - Taxonomy Category: `AI & ML`
  - Extraction Confidence: `99.0%`
  - Character Range Span: `[1182, 1189]`
  - Verified Resume Text Excerpt: `"AI / ML: PyTorch, Hugging Face, Qdrant, Milvus..."`

---

### Step 4: Hybrid ATS Matching & Requisition Ranking
* **USER ACTION:** User navigates to `/match` and selects requisition `req-01` (*Principal AI & Distributed Systems Architect*).
* **APPLICATION PROCESSING:**
  1. Generates 384-dimensional dense semantic embedding vectors for candidate and job descriptions.
  2. Computes cosine similarity between candidate vector and job vector.
  3. Computes Okapi BM25 keyword score ($k_1=1.5, b=0.75$).
  4. Fuses rankings using Reciprocal Rank Fusion:
     $$\text{RRF}(d) = \frac{1}{60 + \text{rank}_{\text{dense}}} + \frac{1}{60 + \text{rank}_{\text{bm25}}}$$
* **BACKEND/API:** `matchCandidateToJobs()` in `src/lib/intelligence-engine.ts`.
* **AI/ML/NLP:** High-dimensional trigram hashing + Okapi BM25 + Reciprocal Rank Fusion.
* **DATABASE:** Saves selected job to active candidate dossier.
* **OUTPUT:**
  - Dense Cosine Similarity: `0.490 / 1.000`
  - Okapi BM25 Sparse: `3.84 pts`
  - Fused RRF Rank: `0.03279`
  - Overall Hybrid Fit: `89.4%`
  - Matched Skills: 8 skills (Python, Go, PyTorch, Qdrant, FastAPI, Docker, SHAP, RRF)
  - Missing Skills: `Triton Inference Server`, `Kubeflow`

---

### Step 5: Psychometric Assessment & Telemetry Stream
* **USER ACTION:** User navigates to `/assessment`, answers the dynamic programming invariant question, and clicks "Stream Item Telemetry".
* **APPLICATION PROCESSING:**
  1. Measures response latency ($1420\text{ ms}$).
  2. Checks correctness (Option A selected = Correct).
  3. Computes updated Classical Test Theory difficulty index ($p = 0.81$).
  4. Checks Item Response Theory sample gate ($N = 26 < 200 \rightarrow \text{Gated}$).
* **BACKEND/API:** `intelligence-engine` assessment telemetry handler.
* **AI/ML/NLP:** CTT difficulty calibration index ($p = \frac{\text{correct}}{\text{total}}$).
* **DATABASE:** Appends telemetry event to `candidate.assessmentTelemetry` in `localStorage`.
* **OUTPUT:** Telemetry card displays logged event, response time `1.42s`, $p$-value `0.81`, and IRT Gated status.

---

### Step 6: Safe Sandboxed Algorithm Execution
* **USER ACTION:** User navigates to `/coding` and clicks "Execute in Sandbox".
* **APPLICATION PROCESSING:**
  1. Runs security pre-filter against forbidden keywords (`process`, `require`, `fs`, `fetch`, `prototype`, `constructor`).
  2. Evaluates Kadane's algorithm solution against 4 deterministic test cases inside an isolated execution boundary.
  3. Tracks execution latency and pass/fail counts.
* **BACKEND/API:** `executeSafeJavaScriptSandbox()` in `src/lib/intelligence-engine.ts`.
* **AI/ML/NLP:** Automated sandbox execution and test oracle comparison.
* **DATABASE:** Saves submission record to active candidate dossier.
* **OUTPUT:**
  - Status: `ACCEPTED (4/4 Test Cases Passed)`
  - Execution Latency: `89.2 ms`
  - Peak Memory Footprint: `18.4 MB`
  - Terminal Stdout: Prints test case outputs `6`, `1`, `23`, `-1` with `PASS ✓`.

---

### Step 7: Model Explainability & Shapley Scorecard
* **USER ACTION:** User navigates to `/feedback` to inspect readiness scorecard.
* **APPLICATION PROCESSING:**
  1. Synthesizes feature vector (19 skills, 8.0 yrs exp, 100% code pass, $p=0.81$ telemetry, 2 missing skills).
  2. Computes constituent Shapley additive feature lifts from baseline $68.0\text{ pts}$.
  3. Calculates final readiness score ($86.3 / 100$).
* **BACKEND/API:** `computeShapleyAttributions()` in `src/lib/intelligence-engine.ts`.
* **AI/ML/NLP:** Linear surrogate Shapley feature attribution decomposition.
* **DATABASE:** Saves scorecard to active candidate dossier in `localStorage`.
* **OUTPUT:**
  - Base Population Average: `68.0 pts`
  - Verified Skills Lift: `+7.2 pts`
  - Calibrated Experience Lift: `+5.8 pts`
  - Coding Benchmark Pass: `+4.2 pts`
  - Psychometric Telemetry Lift: `+3.1 pts`
  - Missing Skills Penalty: `-2.0 pts`
  - Net Shapley Lift: `+18.3 pts` $\rightarrow$ Final Readiness Score: **`86.3 / 100`**.

---

### Step 8: Recruiter Pipeline & Candidate Inspection
* **USER ACTION:** Recruiter navigates to `/recruiter/candidates` and clicks "Inspect Dossier".
* **APPLICATION PROCESSING:** Reads candidate pool from `StorageService`, renders candidate ranking cards and full dossier.
* **BACKEND/API:** `StorageService.getAllCandidates()`.
* **AI/ML/NLP:** None (Presentation layer).
* **DATABASE:** Reads from `localStorage`.
* **OUTPUT:** Dossier page displays candidate's full resume text, character-span provenance, 4-engine score gauges, and offer advance CTA.

---

### Step 9: Grounded AI Career Assistant Chatbot
* **USER ACTION:** Candidate opens floating AI Chatbot on `/modules/career` and queries: *"What skills am I missing?"*
* **APPLICATION PROCESSING:**
  1. Chatbot intercepts query and loads candidate dossier from `StorageService.getActiveCandidate()`.
  2. Checks candidate's target job (`req-01`) and retrieves missing skills list (`Triton Inference Server`, `Kubeflow`).
  3. Formats factual response grounded in candidate record with zero hallucination.
* **BACKEND/API:** `queryAssistant()` in `src/lib/ai-assistant-service.ts`.
* **AI/ML/NLP:** Deterministic candidate-grounded query engine.
* **DATABASE:** Reads active dossier from `localStorage`.
* **OUTPUT:**
  ```markdown
  # Skill Gap Analysis for Target Role
  **Target Requisition**: Principal AI & Distributed Systems Architect
  **Hybrid Match Fit**: 89.4%

  ### Recommended Skills to Acquire:
  * ⚠ Triton Inference Server — Currently absent from resume tokens.
  * ⚠ Kubeflow — Adding proven project experience recovers +1.0 to +2.0 readiness points.
  ```
